package cabBook;

import org.springframework.data.jpa.repository.JpaRepository;

public interface Inter extends JpaRepository<Book, Integer>{

}
